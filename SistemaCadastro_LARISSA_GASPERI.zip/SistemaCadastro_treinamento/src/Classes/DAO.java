package Classes;
import java.util.Scanner;

/**
 * 
 * A Classe DAO corresponde a interface no programa, onde as op��es ser�o mostradas, bem como todas as
 * a��es realizadas pelo usu�rio dentro do sistema; 
 * 
 * @author Larissa Gasperi
 *
 */

public class DAO 
{

	public static void main(String[] args)
	{

		/**
		 * A vari�vel Scanner scan � respons�vel por fazer a leituta dos dados digitados pelo usu�rio atrav�s da interface;  
		 */

		Scanner scan = new Scanner(System.in);

		/**
		 * A var�avel "opcao" corresponde aos n�meros do switch dpara determinada fun��o; 
		 * 
		 */	

		int opcao;

		/**
		 * Os ArrayLists est�o instanciados para permiss�o de acesso de seus dados; 
		 */

		Pessoas pessoasFase1 = new Pessoas();
		Pessoas pessoasFase2 = new Pessoas();
		Salas Sala1 = new Salas();
		Salas Sala2 = new Salas();
		Caf�s Caf�1 = new Caf�s();
		Caf�s Caf�2 = new Caf�s();

		/**
		 * Op��es dispon�veis no sistema para acesso atrav�s do switch; 
		 */		

		while(true)
		{
			System.out.println("\nEscolha uma das seguintes op��es:\n\n"

					+" 1 - Cadastrar Pessoa na Fase 1\n" 
					+" 2 - Cadastrar Pessoa na Fase 2\n"
					+" 3 - Consulta Sala da fase 1\n"
					+" 4 - Consulta Sala da fase 2\n"
					+" 5 - Consultar Caf� da fase 1\n"
					+" 6 - Consultar Caf� da fase 2\n"
					+" 7 - Listar Pessoas\n"
					+" 8 - Remover pessoa da sala da fase 1\n"
					+" 9 - Remover pessoa da sala da fase 2\n"
					+" 10 - Consultar Pessoa da fase 1\n"
					+" 11 - Consultar Pessoa da fase 2\n"
					+" 12 - Editar nome da pessoa da fase 1\n"
					+" 13 - Editar nome da pessoa da fase 2\n"
					+" 14 - Cadastrar Sala da fase 1\n"
					+" 15 - Cadastrar Sala da fase 2\n"
					+" 16 - Cadastrar Caf� da fase 1\n"
					+" 17 - Cadastrar Caf� da fase 2\n"
					+" 18 - Sair"); 

			System.out.print(" \n Op��o escolhida: ");
			opcao = scan.nextInt();

			switch(opcao)
			{

			case 1:
				
				/**
				 * O case 1 corresponde ao cadastro de pessoas na fase 1 no sistema; 
				 */

				System.out.print("\nNome e sobrenome: ");
				scan.nextLine();
				pessoasFase1.setNome(scan.nextLine());
				pessoasFase1.listagemPessoa(opcao);
				break;

			case 2:

				/**
				 * O case 2 corresponde ao cadastro de pessoas na fase 2 no sistema; 
				 */

				System.out.print("\nNome e sobrenome: ");
				scan.nextLine();
				pessoasFase2.setNome2(scan.nextLine());
				pessoasFase2.listagemPessoa2(opcao);
				break;

			case 3:

				/**
				 * O case 4 corresponde a listagem das pessoas presentes na sala da fase 1,  atrav�s da chamda da listagem correspondente (listagemSala1 e listagemPessoa); 
				 */

				System.out.println(" _____________________________________________");
				System.out.println("                 LISTA DE PESSOAS NA SALA "+Sala1.listagemSala1(opcao)   );
				System.out.println(" _____________________________________________");
				System.out.println("Pessoas na sala: "+pessoasFase1.listagemPessoa(opcao));
				System.out.println("_____________________________________________\n\n");
				break;

			case 4:

				/**
				 * O case 4 corresponde a listagem das pessoas presentes na sala da fase 2, atrav�s da chamda da listagem correspondente (listagemSala2 e listagemPessoa2); 
				 */
				
				System.out.println(" _____________________________________________");
				System.out.println("                 LISTA DE PESSOAS NA SALA "+Sala2.listagemSala2(opcao)   );
				System.out.println(" _____________________________________________");
				System.out.println("Pessoas na sala: "+pessoasFase2.listagemPessoa2(opcao));
				System.out.println("_____________________________________________\n\n");
				break;


			case 5:

				/**
				 * O case 6 corresponde a listagem das pessoas presentes no caf� da fase 1; 
				 */

				System.out.println(" _____________________________________________");
				System.out.println("                 CAF�"+Caf�1.listagemCaf�1(opcao)   );
				System.out.println(" _____________________________________________");
				System.out.println("Pessoas no caf�: "+pessoasFase1.listagemPessoa(opcao));
				System.out.println("_____________________________________________\n\n");
				break;

			case 6:

				/**
				 * O case 6 corresponde a listagem das pessoas presentes no caf� da fase 2; 
				 */

				System.out.println(" _____________________________________________");
				System.out.println("                 CAF�"+Caf�2.listagemCaf�2(opcao)   );
				System.out.println(" _____________________________________________");
				System.out.println("Pessoas no caf�: "+pessoasFase2.listagemPessoa2(opcao));
				System.out.println("_____________________________________________\n\n");
				break;

			case 7:

				/**
				 * O case 7 corresponde a listagem de todas as pessoas cadastradas no sistema, atrav�s da chamda das listagens correspondentes de cada fase, 1 e 2; 
				 */

				System.out.println(" _____________________________________________");
				System.out.println("                 LISTA DE PESSOAS");
				System.out.println(" _____________________________________________");
				System.out.println(""+pessoasFase1.listagemPessoa(opcao)+"\tFase: 1"+"\tSala: "+Sala1.listagemSala1(opcao)+"\tCaf�: "+Caf�1.listagemCaf�1(opcao));
				System.out.println(""+pessoasFase2.listagemPessoa2(opcao)+"\tFase: 2"+"\tSala: "+Sala2.listagemSala2(opcao)+"\tCaf�: "+Caf�2.listagemCaf�2(opcao));
				System.out.println("_____________________________________________\n\n");

				break;


			case 8:

				/**
				 * O case 8 corresponde a remo��o de cada pessoa da fase 1 no sistema; 
				 */

				System.out.print("\nNome de quem deseja remover dessa lista: ");
				scan.nextLine();
				pessoasFase1.setNome(scan.nextLine());				
				pessoasFase1.listagemPessoa(opcao);

				break;

			case 9:

				/**
				 * O case 9 corresponde a remo��o de cada pessoa da fase 2 no sistema; 
				 */

				System.out.print("\nNome de quem deseja remover dessa lista: ");
				scan.nextLine();
				pessoasFase2.setNome2(scan.nextLine());				
				pessoasFase2.listagemPessoa2(opcao);


				break;

			case 10:

				/**
				 * O case 10 corresponde a consulta de cada pessoa da fase 2 no sistema; 
				 */
				
				scan.nextLine();
				pessoasFase1.listagemPessoa(opcao);

				break;

			case 11:
				
				/**
				 * O case 11 corresponde a consulta de cada pessoa da fase 2 no sistema; 
				 */

				scan.nextLine();
				pessoasFase2.listagemPessoa2(opcao);

				break;

			case 12:
				
				/**
				 * O case 12 corresponde a edi��o do nome de pessoas da fase 1 no sistema; 
				 */

				scan.nextLine();
				pessoasFase1.listagemPessoa(opcao);


				break;

			case 13:

				/**
				 * O case 12 corresponde a edi��o do nome de pessoas da fase 2 no sistema; 
				 */
				
				scan.nextLine();
				pessoasFase2.listagemPessoa2(opcao);

				break;

			case 14:

				/**
				 * O case 14 corresponde ao cadastro de salas na fase 1 no sistema; 
				 */

				System.out.print("\nNome da Sala: ");
				scan.nextLine();
				Sala1.setNomeSala(scan.nextLine());
				Sala1.listagemSala1(opcao);
				break;

			case 15:

				/**
				 * O case 14 corresponde ao cadastro de salas na fase 2 no sistema; 
				 */

				System.out.print("\nNome da Sala: ");
				scan.nextLine();
				Sala2.setNomeSala2(scan.nextLine());
				Sala2.listagemSala2(opcao);

				break;

			case 16:

				/**
				 * O case 16 corresponde ao cadastro de caf�s na fase 1 no sistema; 
				 * Onde o ArrayList Caf�1 recebe o nome digitado pelo usu�rio atrav�s da interface pela chamada da listagemCaf�1 na opcao determinada;
				 */

				System.out.print("\nNome do Caf� 1: ");
				scan.nextLine();
				Caf�1.setNomeCaf�(scan.nextLine());
				Caf�1.listagemCaf�1(opcao);

				break;

			case 17:

				/**
				 * O case 17 corresponde ao cadastro de caf�s na fase 2 no sistema; 
				 * Onde o ArrayList Caf�2 recebe o nome digitado pelo usu�rio atrav�s da interface pela chamada da listagemCaf�2 na opcao determinada;
				 */

				System.out.print("\nNome do Caf� 2: ");
				scan.nextLine();
				Caf�2.setNomeCaf�2(scan.nextLine());
				Caf�2.listagemCaf�2(opcao);
				break;

			case 18:
				
				/**
				 * op��o para encerrar o sistema; 
				 */

				System.exit(0);

				break;

			default:

				System.out.println("\t\t\t\t\t Op��o inexistente! Escolha uma das dispon�veis.\n\n");
			}
		}
	}	

}