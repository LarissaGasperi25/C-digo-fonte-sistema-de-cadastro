package Classes;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Classe Pessoas
 * 
 * Diz respeito a todos os requisitos correspondentes �s pessoas no sistema;
 * Fun��es correspondentes: cadastro de pessoas, Cadastro de pessoas nas salas, Cadastro de pessoas nos caf�s;
 */

public class Pessoas {

	/**
	 * A var�avel "nome" armazena o nome completo de pessoas da fase 1, cadastrado pelo usu�rio no sistema ; 
	 */	

	public String nome;

	/**
	 * A var�avel "nome2" armazena o nome completo de pessoas da fase 2, cadastrado pelo usu�rio no sistema ; 
	 */	

	public String nome2;

	/**
	 * A var�avel "consultar" armazena o nome completo de pessoas da fase 1 e fase 2, na fun��o de consulta de cada pessoa 
	 * cadastrada pelo usu�rio; 
	 */		

	public String consultar;

	/**
	 * A var�avel "selecao" corresponde aos n�meros do switch de determinada fun��o; 
	 * 
	 */		

	int selecao;

	/**
	 * O ArrayList pessoasFase1 � o local que armazena os dados das pessoas cadastradas na fase 1; 
	 *    
	 */

	List<String> pessoasFase1 = new ArrayList<String>();

	/**
	 * O ArrayList pessoasFase2 � o local que armazena os dados das pessoas cadastradas na fase 2; 
	 *    
	 */	

	List<String> pessoasFase2 = new ArrayList<String>();

	/**
	 * A vari�vel Scanner inU � respons�vel por fazer a leituta dos dados digitados pelo usu�rio;  
	 */

	Scanner inU = new Scanner(System.in);

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;

	}

	public String getNome2() {
		return nome2;
	}

	public void setNome2(String nome2) {
		this.nome2 = nome2;
	}

	/**
	 * A Lista "listagemPessoa" � respons�vel por armazenar os dados do ArrayList pessoasFase1; 
	 * 
	 * As condicionais if setam fun��es correspondentes a cada switch referente 
	 * �s pessoas da fase 1 no treinamento (ArrayList "pessoasFase1");
	 *  
	 * @param selecao
	 * @return pessoasFase1
	 */

	public List<String> listagemPessoa(int selecao)

	{  
		/**
		 * A sele��o 1 diz respeito ao cadastro de pessoas da fase 1 no sistema, onde cada nome
		 * digitado pelo usu�rio � adicionado ao ArrayList "pessoasFase1"
		 */

		if (selecao == 1) {

			pessoasFase1.add(getNome());
			System.out.println("\nAdicionado com sucesso!");
		}	

		/**
		 * A sele��o 8 se refere a remoc�o de pessoas da fase 1 do sistema, onde cada nome
		 * digitado pelo usu�rio � removido do ArrayList "pessoasFase1"
		 */

		if (selecao == 8) {

			pessoasFase1.remove(getNome());	
			System.out.println("\nRemovido com sucesso!\n");	
			System.out.println("\nPara cadastrar esta pessoa na fase 2 escolha a op��o 2 e recadastre seu nome.\n");
		}

		/**
		 * A sele��o 10 se refere a consulta de cada pessoa da fase 1 no sistema, a partir da busca pelo nome cadastrado
		 * no ArrayList "pessoasFase1";
		 * Exibe as informa��es: nome e fase; 
		 */

		if(selecao == 10 )
		{
			System.out.println("\nDigite a pessoa que deseja consultar: ");
			consultar = inU.nextLine();

			if (pessoasFase1.contains(consultar)) {
				System.out.println("\t\t\t\t\t _____________________________________________");
				System.out.println("\t\t\t\t\t                  PESSOAS");
				System.out.println("\t\t\t\t\t _____________________________________________");

				System.out.println("\t\t\t\t\t\tNome: "+ consultar + "\n\t\t\t\t\t\tFase: 1");

				System.out.println("\t\t\t\t\t _____________________________________________\n\n");


			} else {
				System.out.println("\nPessoa n�o presente na lista!\n");
			}
		}

		/**
		 * A sele��o 12 se refere a edi��o do nome de pessoas da fase 1, caso o cadastro tenha sido
		 * feito errado; 
		 * A edi��o ocorre a partir da busca pelo nome cadastrado no ArrayList "pessoasFase1" e ent�o o recadastro do novo nome; 
		 * 
		 */

		if(selecao == 12 )
		{
			System.out.println("\nDigite a pessoa que deseja alterar: ");
			String alteracao = inU.nextLine();
			System.out.println("\nDigite a pessoa para a qual deseja alterar: ");
			String alteracao2 = inU.nextLine();


			if (pessoasFase1.contains(alteracao)) {
				pessoasFase1.remove(alteracao);
				pessoasFase1.add(alteracao2);
			}else {
				System.out.println("N�o presente na lista");
			}
		}

		return pessoasFase1; 

	}

	/**
	 * A Lista "listagemPessoa2" � respons�vel por armazenar os dados do ArrayList pessoasFase1; 
	 * 
	 * As condicionais if setam fun��es correspondentes a cada switch referente 
	 * �s pessoas da fase 2 no treinamento (ArrayList "pessoasFase2");
	 *  
	 * @param selecao
	 * @return pessoasFase2
	 */

	public List<String> listagemPessoa2(int selecao)

	{  
		/**
		 * A sele��o 2 se refere ao cadastro de pessoas da fase 2 no sistema, onde cada nome
		 * digitado pelo usu�rio � adicionado ao ArrayList "pessoasFase1"
		 */

		if (selecao == 2) {

			pessoasFase2.add(getNome2());
			System.out.println("\nAdicionado com sucesso!");
		}

		/**
		 * A sele��o 9 diz respeito a remoc�o de pessoas da fase 2 do sistema, onde cada nome
		 * digitado pelo usu�rio � removido do ArrayList "pessoasFase2"
		 */

		if (selecao == 9) {

			pessoasFase2.remove(getNome2());	
			System.out.println("\nRemovido com sucesso!");	
			System.out.println("\nPara cadastrar esta pessoa na fase 1 escolha a op��o 1 e recadastre seu nome.\n");	

		}

		/**
		 * A sele��o 11 se refere a consulta de cada pessoa da fase 2 no sistema, a partir da busca pelo nome cadastrado
		 * no ArrayList "pessoasFase2";
		 * Exibe as informa��es: nome e fase; 
		 */

		if(selecao == 11 )
		{
			System.out.println("\nDigite a pessoa que deseja consultar: ");
			consultar = inU.nextLine();

			if (pessoasFase2.contains(consultar)) {
				System.out.println("\t\t\t\t\t _____________________________________________");
				System.out.println("\t\t\t\t\t                  PESSOAS");
				System.out.println("\t\t\t\t\t _____________________________________________");

				System.out.println("\t\t\t\t\t\tNome: "+ consultar + "\n\t\t\t\t\t\tFase: 2");

				System.out.println("\t\t\t\t\t _____________________________________________\n\n");


			} else {
				System.out.println("\nPessoa n�o presente na lista!\n");
			}
		}

		/**
		 * A sele��o 13 se refere a edi��o do nome de pessoas da fase 2, caso o cadastro tenha sido
		 * feito errado; 
		 * A edi��o ocorre a partir da busca pelo nome cadastrado no ArrayList "pessoasFase2" e ent�o o recadastro do novo nome; 
		 * 
		 */

		if(selecao == 13 )
		{
			System.out.println("\nDigite a pessoa que deseja alterar: ");
			String alteracao = inU.nextLine();
			System.out.println("\nDigite a pessoa para a qual deseja alterar: ");
			String alteracao2 = inU.nextLine();


			if (pessoasFase2.contains(alteracao)) {
				pessoasFase2.remove(alteracao);
				pessoasFase2.add(alteracao2);
			}else {
				System.out.println("N�o presente na lista");
			}
		}
		return pessoasFase2; 

	}
}